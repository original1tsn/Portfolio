def fun(a):
	if a > 0:
		for n in range(a):
			print(' --- '*a)
			print('|    '*(a+1))	
		print(' --- '*a)
		print(' ')
	else:
		print(' ')
def funn(b):
	fun(b)
	if b > 0:
		funn(b-1)
	
funn(20)
