ij = 0
xy = 0
while ij <6:
	while xy < 10:
		xy+=1
		print(ij,xy)
	ij+=1