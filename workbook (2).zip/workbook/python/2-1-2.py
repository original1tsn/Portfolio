the_world_is_flat = True
if the_world_is_flat:
	print("Be careful not to fall off!")