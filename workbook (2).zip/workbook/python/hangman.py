fin = open('words.txt')
dictionary = []
alphabet = 'abcdefghijklmnopqrstuvwxyz'
guesses = []
errors = 0
import random
for line in fin:
	fin.readline()
	word = line.strip()
	dictionary.append(word)
def pickword(list):
	return list[random.randint(0, len(list))]
	
def board(guesses,wrong, word):
	print('  ____')
	print('  |   |')
	if wrong>0:
		print('  |   O')
	else:
		print('  |  ')
		
	if wrong<2:
		print('  |  ')
	elif wrong == 2:
		print('  |  /')
	elif wrong == 3:
		print('  |  /|')
	elif wrong>3:
		print('  |  /|\\')
		
	if wrong<5:
		print('  |  ')
	elif wrong == 5:
		print('  |   /')
	elif wrong > 5:
		print('  |   /\\          The word was '+ word +', You lose. Better luck next time!')
	print('  |\n-----------')
	
	blanks = '    '
	print(blanks)
	for i in word:
		if i not in guesses:
			blanks += ' - '
		else: 
			blanks += ' ' + i + ' '
	print(blanks)
	blanks = '    '
	print(blanks)
	for i in alphabet:
		if i in guesses and i in word:
			blanks += ' :^D '
		elif i in guesses and i not in word:
			blanks += ' :( '
		else: 
			blanks += ' ' + i + ' '
	print(blanks)
def game():	
	guesses = []
	errors = 0
	correct = 0
	word = pickword(dictionary)
	over = False
	while over == False:
		board(guesses, errors, word)
		guess = str(input('Enter your guess: ')).lower()
		if guess not in guesses and guess in alphabet and len(guess) == 1:
			guesses.append(guess)
			if guess not in word:
				errors += 1
				
			if errors == 6:
				over = True
				board(guesses, errors, word)
			done = ''
			for char in word:
				if char in guesses:
					done += 'y'
				else:
					done +='n'
			if 'n' not in done:
				over = True
				board(guesses, errors, word)
				print('    CONGRATULATIONS YOU WIN!!')
		else:
			print('try again, you cannot guess that!')
game()
again = 'nope'
while again == 'nope': 
	again = str(input('play again (y/n)?')).lower()
	if 'n' not in again and 'y' not in again:
		again = 'nope'
	elif 'y' in again:
		again = 'nope'
		game()
	else: 
		print('Thanks for playing!')
