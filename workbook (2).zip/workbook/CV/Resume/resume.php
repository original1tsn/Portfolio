<!DOCTYPE html>
<html>
	<head>
		<title> Thomas Neuman</title>
		<link rel="stylesheet" href="style.css">
		<style>
			@font-face {
				font-family: 'sans-forgetica';
				src: url('Sans Forgetica/SansForgetica-Regular.otf');
			}
			article {
				padding: 3%;
				text-indent:3%;
				border-radius:2em;
				font-family: <?php echo $_POST["font"]; ?>"Times New Roman",sans-forgetica, Times, serif;
			}
		</style>
	</head>
	<body>
		<header>
			<aside>
				<p>S</p>
				<p>P</p>
				<p>Q</p>
				<p>R</p>
			</aside>
			<aside>
				<p>S</p>
				<p>P</p>
				<p>Q</p>
				<p>R</p>
			</aside>
			<h3>Thomas Neuman</h3>
			<p>GD STN MAIN</p>
			<p>T5J 2G8</p>
			<p><a href="tel:7807229021">780-722-9021</a></p>
			<p><a href="mailto: original1tsn@gmail.com">original1tsn@gmail.com</a></p>
			<hr>
			<form action="/resume.php" method="get">
				<select name="font" >
					<option value="Times New Roman" selected>Times New Roman</option>
					<option value="sans-forgetica">Sans Forgetica</option>
					<option value="Times">Times</option>
					<option value="serif">Serif</option>
				</select>
				<input type="submit">
			</form>
		</header>
		<article>
			<h2>Formal Education</h2>
			<ul style="none">
				<li>Lindsay Thurber Comprehensive High School: GED 2010</li>
				<li>Red Deer College: 1st year bachelors of Engineering ( nano-computer) 2011-2012</li>
				<li>University of Alberta: 2nd year bachelors of Engineering ( nano-computer) 2012-2013</li>
			</ul>
			<p><br></p>
		</article>
		<article>
			<h2>Skills/ Training</h2>
			<ul style="none">
				<li>Quick Learner</li>
				<li>Standard First Aid: Expired</li>
				<li>EICT course by ballad consulting</li>
				<li>Technically Minded</li>
				<li>Quality Oriented</li>
				<li>Computer Profficient(Coding, Maintenance, Use, Design)</li>
				<li>Scholar (always studying various things)</li>
				<li>Leadership</li>
				<li>Planning</li>
			</ul>
		</article>
		<article>
			<h2>Interests/ Hobbies</h2>
			<ul style="none">
				<li>Math</li>
				<li>General Sciences</li>
				<li>Technology Design/Development</li>
				<li>Machinery</li>
				<li>Automation</li>
				<li>Programming</li>
				<li>Studying</li>
				<li>Psychology (Evolutionary/ Clinical)</li>
				<li>Reading</li>
				<li>Strength Training/ Nutrition</li>
			</ul>
		</article>
		<article>
			<h2>Work experience</h2>
			<ul style="none">
				<li>Asplundh Canada: May 2018- Sept 2018, Grounsman/Foreman
				<ul style="none">
					<li>Sprayed brush under powerline</li>
					<li>Drove truck and trailer</li>
					<li>Mixed chem</li>
					<li>Maintain logs</li>
					<li>Maintain paperwork</li>
					<li>Send paperwork</li>
					<li>Minor maintenance and repairs</li>
					<li>Kept track of timesheets and submition</li>
					<li>Planning for routes and weather</li>
					<li>Navigating</li>
					<li>Crew managment</li>
				</ul>
				</li>
				<li>KSN interiors: Dec 2017- April 2017, Labour
				<ul style="none">
					<li>Drive</li>
					<li>Clean up</li>
					<li>Deliver, load, and unload materials</li>
					<li>Assist with Construction</li>
					<li>Demolition</li>
				</ul>
				</li>
				<li>Dunn Ruyys: Aug 2017- Oct 2017, Painters assistant
				<ul style="none">
					<li>Paint</li>
					<li>Prep</li>
					<li>Clean</li>
				</ul>
				</li>
				<li>Costco Wholesale: Sept 2014- Jul 2017, Front End Assistant, Cashier, Garden center Assistant, Member Service Assistance
				<ul style="none">
					<li>Stocking</li>
					<li>Assisting cashiers</li>
					<li>Money handleing</li>
					<li>Major appliance sales</li>
					<li>Member service desk sales</li>
					<li>Assist members with issues brought to the member service desk</li>
					<li>Credit card sales </li>
				</ul>
				</li>
				<li>City of Edmonton: Jan 2014- Feb 201, Lifeguard
				<ul style="none">
					<li>Monitor Facility</li>
					<li>Maintain Facility</li>
					<li>Interact with patrons</li>
					<li>Ensure saftey of everyone</li>
				</ul>
				</li>
				<li>MTI Global Services: March 2014- Present, Technician
				<ul style="none">
					<li>Merchandise and audit sites</li>
					<li>Troubleshoot issues</li>
					<li>Repairs</li>
					<li>Installs</li>
					<li>Maintain customer relationships</li>
					<li>Firmware updating</li>
					<li>Identify issues and order parts </li>
					<li>Train store staff</li>
				</ul>
				</li>
				<li>City of Edmonton: Jan 2014- Feb 2014, Lifeguard
				<ul style="none">
					<li>Monitor Facility</li>
					<li>Maintain Facility</li>
					<li>Interact with patrons</li>
					<li>Ensure saftey of everyone</li>
				</ul>
				</li>
				<li>Mosaic: Oct 2013- Dec 2013, Lifeguard
				<ul style="none">
					<li>Merchandise product to plans</li>
					<li>Stocking</li>
					<li>Deconstruct and build displays</li>
				</ul>
				</li>
				<li>MSI Canada: Jul 2013- Sept 2013, Merchandiser
				<ul style="none">
					<li>Merchandise product to plans</li>
					<li>Some stocking</li>
				</ul>
				</li>
				<li>RV Country: Jun 2013- Jun 2013, Shop Assistant
				<ul style="none">
					<li>Maintain shop</li>
				</ul>
				</li>
				<li>R&R Turf: May 2012- Aug 2012, Crew Chief
				<ul style="none">
					<li>Mow and weedwhack lawns</li>
					<li>Assist with irrigation system install and maintenance</li>
					<li>Assist with landscaping</li>
					<li>Train and lead crews</li>
					<li>Spring cleanup</li>
				</ul>
				</li>
				<li>R&R Turf: Mar 2011- Aug 2011, Landscaper
				<ul style="none">
					<li>Mow and weedwhack lawns</li>
					<li>Assist with irrigation system install and maintenance</li>
					<li>Assist with landscaping</li>
					<li>Snow removal</li>
					<li>Spring cleanup</li>
				</ul>
				</li>
			</ul>
		</article>
	</body>
</html>