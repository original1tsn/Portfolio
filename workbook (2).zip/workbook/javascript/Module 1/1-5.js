function myfunction(){
				document.getElementById("demo").innerHTML = "Paragraph changed.";
			}